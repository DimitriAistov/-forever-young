for A in range (1,11):
    print (A * 4)

print('----------------------------------------------')

for B in range (30,-1,-1):
    print (B)

print('----------------------------------------------')

for C in range (0,24,+1):
    
    if C <= 12:
        print(str(C) + 'AM')
    elif C > 12:
        print(str(C) +  'PM')

print('----------------------------------------------')

for D in range (20,52,2):
    print(D)


